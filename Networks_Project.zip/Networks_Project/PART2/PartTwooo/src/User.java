/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HITECH
 */
public class User {
    private String username;
    private String password;
    
    //constructor 
    public User(String username, String password){
        this.username = username;
        this.password = password;
    }
    //setters 
    public void setUsername(String username){
        this.username = username;
    }
    public void setPassword(String password){
        this.password = password;
    }
    //getters
    public String getUsername(){
        return username;
    }        
    public String getPassword(){
        return password;
    }
    //override equals
    @Override
    public boolean equals(Object obj){
        if(obj instanceof User){
            User user = (User) obj;
            if(user.getUsername().equals(username) && user.getPassword().equals(password))
                return true;
            return false;
        }
        return false;
    }
}