
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Vector;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author HITECH
 */
public class FileProcessing {
   private File file = new File("src/users.txt");
   private Scanner scanner;
   private Vector <User> users;
   public FileProcessing(){
       try{
           scanner = new Scanner(file);
           users = new Vector <User> ();
           
           while(scanner.hasNextLine()){
                String line = scanner.nextLine(); //read a line
                String [] fields = line.split(","); //split it
                User user = new User (fields[0],fields[1]); //create a user
                users.add(user); //add the user to the users vector
           }
       }catch(FileNotFoundException ex){
           System.out.println("File Not Found Exception");
       }
   }
   public User search(String string){
       String info [] = string.split(",");
       User temp = new User(info[0],info[1]);
       for(User user: users)
           if(user.equals(temp))
               return user;
       return null;
   }
}
