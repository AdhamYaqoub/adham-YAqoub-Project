public class Main {
    public static void main(String[] args) {


        Client_Chat c1 = new Client_Chat();
        c1.setVisible(true);
        Client_Chat c2 =  new Client_Chat();
        c2.setVisible(true);
    }
}