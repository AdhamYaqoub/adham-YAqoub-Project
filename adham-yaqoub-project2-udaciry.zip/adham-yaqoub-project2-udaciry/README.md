# My Landing Page Website

This is a simple and responsive Landing Page website created using **HTML**, **CSS**, and **JavaScript**. The website showcases my skills, projects, and contact information in an elegant and user-friendly layout.

---

## Features
1. **Responsive Design**:
   - Adapts to various screen sizes and devices using CSS.
   
2. **Navigation Bar**:
   - Dynamically generated links to website sections.

3. **Smooth Scrolling**:
   - Smooth transitions to sections when navigation links are clicked.

4. **Interactive Hero Section**:
   - Displays a welcoming message and call-to-action button.

5. **Skills Section**:
   - Highlights skills with progress bars.

6. **Projects Section**:
   - Displays personal projects with brief descriptions and images.

7. **Contact Form**:
   - Collects user input and displays it in a modal dialog.

8. **Back to Top Button**:
   - Visible after scrolling down, for easy navigation to the top.

9. **Dynamic Active Sections**:
   - Automatically highlights the active section while scrolling.

10. **Downloadable Resume**:
    - Option to download my CV in PDF format.

---

## File Structure
```plaintext
├── index.html          # Main HTML file
├── css/
│   └── styles.css      # Styling for the website
├── js/
│   └── app.js          # JavaScript for interactive features
│   ├── adham.jpg       # About section image
│   ├── img2.jpg        # Hero section background
│   ├── img3.jpg        # Project 1 image
│   ├── img4.jpg        # Project 2 image
│   ├── img5.jpg        # Project 3 image
├── adham-yaqoub-cv.pdf # Resume file
└── README.md           # Project overview
