document.addEventListener("DOMContentLoaded", () => {
    const navbar = document.querySelector("#navbar__list");
    const sections = document.querySelectorAll("section");

    // التحقق من وجود العناصر
    if (!navbar || !sections.length) {
        console.error("Navbar or sections not found!");
        return;
    }

    // إنشاء قائمة التنقل
    function buildNav() {
        const fragment = document.createDocumentFragment();
        sections.forEach((section) => {
            const navItem = document.createElement("li");
            const sectionName = section.dataset.nav || "Unnamed Section";
            navItem.innerHTML = `<a href="#${section.id}" class="menu__link">${sectionName}</a>`;
            fragment.appendChild(navItem);
        });
        navbar.appendChild(fragment);
    }

    // تحديد القسم النشط
    function setActiveSection() {
        let activeSection = null;
        const navbarItems = document.querySelectorAll("#navbar__list li a");

        sections.forEach((section, index) => {
            const rect = section.getBoundingClientRect();
            if (rect.top >= -100 && rect.top <= 300) {
                activeSection = section;
            }
            section.classList.remove("active");
        });

        if (activeSection) {
            activeSection.classList.add("active");
            navbarItems.forEach((item) => item.classList.remove("active"));
            const activeLink = document.querySelector(
                `a[href="#${activeSection.id}"]`
            );
            if (activeLink) activeLink.classList.add("active");
        }
    }

    // التمرير السلس عند النقر
    navbar.addEventListener("click", (event) => {
        event.preventDefault();
        const target = event.target;
        if (target.tagName === "A") {
            const section = document.querySelector(target.getAttribute("href"));
            if (section) {
                section.scrollIntoView({ behavior: "smooth" });
            }
        }
    });

    // تحسين الأداء باستخدام Debouncing
    window.addEventListener("scroll", debounce(setActiveSection, 100));

    // زر الرجوع للأعلى
    const backToTopBtn = document.createElement("button");
    backToTopBtn.textContent = "↑";
    backToTopBtn.id = "back-to-top";
    document.body.appendChild(backToTopBtn);

    backToTopBtn.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
    });

    window.addEventListener("scroll", () => {
        if (window.scrollY > 500) {
            backToTopBtn.classList.add("visible");
        } else {
            backToTopBtn.classList.remove("visible");
        }
    });

    // تحسين تصميم زر الرجوع للأعلى
    const style = document.createElement("style");
    style.textContent = `
        #back-to-top {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 15px;
            font-size: 18px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            opacity: 0;
            transition: opacity 0.3s ease, transform 0.3s ease;
        }
        #back-to-top.visible {
            opacity: 1;
            transform: translateY(0);
        }
        #back-to-top:not(.visible) {
            transform: translateY(20px);
        }
    `;
    document.head.appendChild(style);

    // استدعاء الوظائف
    buildNav();
    setActiveSection();

    const hamburgerMenu = document.getElementById('hamburgerMenu');
    const navbarList = document.getElementById('navbar__list');

    // عند النقر على أيقونة الـ Hamburger Menu
    hamburgerMenu.addEventListener('click', () => {
        navbarList.classList.toggle('active');
    });
});

// Debouncing Function لتحسين الأداء
function debounce(func, wait) {
    let timeout;
    return function (...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}
const hamburgerMenu = document.getElementById("hamburgerMenu");
const navbarList = document.getElementById("navbar__list");

hamburgerMenu.addEventListener("click", () => {
    navbarList.classList.toggle("active");
});
document.addEventListener("DOMContentLoaded", function() {
    const hamburgerMenu = document.getElementById('hamburgerMenu');
    const navbarList = document.getElementById('navbar__list');

    hamburgerMenu.addEventListener('click', function() {
        navbarList.classList.toggle('active');
    });
});
